<?php
    require_once("db.php");

    // $result = sendActivationEmail('tronghien123654@gmail.com','hello');
    // var_dump($result);
    update_product('a','111','asdfsda','anh.png',8);
?>
<?php
    session_start();
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit();
    }
    require_once('db.php');
    // Read data product from database
    $sql= 'select * from product';
    $success = '';
    $error = '';
    $conn = open_database();
    $result = $conn->query($sql);
    $amount = $result->num_rows;
    if($amount==0){
        echo 'Connected, but not data';
    }

    // Get POST data
    if(isset($_POST['name_delete'])){
        $result = delete_product($_POST['name_delete']);
        if($result['code']==0){
            $success = $result['success'];
            header("Refresh:0");

        }else{
            $error = $result['error'];
        }  
    }


    if (isset($_GET['name']) && isset($_GET['price']) && isset($_GET['desc'])&& isset($_GET['id']))
    {
        
        $name = $_GET['name'];
        $price = $_GET['price'];
        $desc = $_GET['desc'];
        $id = $_GET['id'];
        echo $name,$price,$desc,$id;
        
        
        if (empty($name)) {
            $error = 'Hãy nhập tên sản phẩm';
        }
        else if (intval($price) <= 0) {
            $error = 'Giá của sản phẩm không hợp lệ';
        }
        else if (intval($price) < 1000000 || intval($price) % 10000 != 0) {
            $error = 'Giá sản phẩm phải trên 1,000,000đ và là bội số của 10,000 đ';
        }
        else if (empty($desc)) {
            $error = 'Hãy nhập mô tả của sản phẩm';
        }
        else if ($_FILES['image']['error'] != UPLOAD_ERR_OK) {
            $error = 'Vui lòng upload ảnh của sản phẩm';
        }
        else {
            $result = update_product($name,$price,$desc,$_FILES['image']['name'],$id);
            echo $name,$price,$desc,$_FILES['image']['name'],$id;
            if($result['code']==0){
                $success = $result['success'];
            }else{
                $error = $result['error'];
            }
            
        }
    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Trang chủ - Danh sách sản phẩm</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

    <style>
        body{
            padding-top: 50px;
        }
        table{
            width: 80%;
            text-align: center;
        }
        td{
            padding: 10px;
        }
        tr.item{
            border-top: 1px solid #5e5e5e;
            border-bottom: 1px solid #5e5e5e;
        }

        tr.item:hover{
            background-color: #d9edf7;
        }

        tr.item td{
            min-width: 150px;
        }

        tr.header{
            font-weight: bold;
        }

        a{
            text-decoration: none;
        }
        a:hover{
            color: deeppink;
            font-weight: bold;
        }

        td img {
            max-height: 100px;
        }
    </style>


    <script>
        $(document).ready(function () {
            $(".delete").click(function () {

                $('#myModal').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            });
        });
    </script>

    <table cellpadding="10" cellspacing="10" border="0" style="border-collapse: collapse; margin: auto">

        <tr class="control" style="text-align: left; font-weight: bold; font-size: 20px">
            <td colspan="3">
                <a href="add_product.php">Thêm sản phẩm</a>
            </td>
            <td class="text-right">
                Hello <span class="text-danger"><?=$_SESSION['name']?></span> 
            </td>
            <td class="text-right">
                <a href="logout.php">Đăng xuất</a>
            </td>
        </tr>
        <tr class="header">
            <td>Image</td>
            <td>Name</td>
            <td>Price</td>
            <td>Description</td>
            <td>Action</td>
        </tr>
        <?php
            while(($row= $result->fetch_assoc())){
                $name = $row['name'];
                $price = $row['price'];
                $desc = $row['description'];
                $image = $row['image'];
                $id = $row['id'];
                ?>
                    <tr class="item">
                        <td><img src="images/<?=$image?>"></td>
                        <td><?=$name?></td>
                        <td><?=$price?></td>
                        <td><?=$desc?></td>
                        <td><a onclick="handleEditModel('<?=$name?>','<?=$price?>','<?=$desc?>','<?=$image?>','<?=$id?>')" href="#" class="edit" data-toggle="modal" data-target="#edit-product-detail">Edit</a > | <a onclick="handleDeleteProduct('<?=$name?>')" href="#" class="delete" data-toggle="modal" data-target="#confirm-delete">Delete</a></td>
                    </tr>
                
                <?php
            }
        
        ?>
        <tr class="control" style="text-align: right; font-weight: bold; font-size: 17px">
            <td colspan="5">
                <p>Số lượng sản phẩm: <?=$amount?></p>
            </td>
        </tr>
    </table>


    <!-- Delete Confirm Modal -->
    <div id="confirm-delete" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <hp class="modal-title">Xóa sản phẩm</hp>
                        <button type="button" class="close" data-dismiss="modal" >&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>Bạn có chắc rằng muốn xóa <strong class="product-name">iPhone XS MAX</strong> ?</p>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="name_delete" value="" class="input-name">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Xóa</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Confirm Modal -->
    <div id="edit-product-detail" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <hp class="modal-title">Chỉnh sửa thông tin sản phẩm</hp>
                    <button type="button" class="close" data-dismiss="modal" >&times;</button>
                </div>
                <form method="post" novalidate enctype="multipart/form-data">
                    <div class="modal-body">
                        <p>Nhập thông tin bạn muốn chỉnh sửa</p>
                            <div class="form-group">
                            <label for="name">Tên sản phẩm</label>
                            <input name="name" required class="form-control" type="text" placeholder="Tên sản phẩm" id="name">
                        </div>
                        <div class="form-group">
                            <label for="price">Giá bán</label>
                            <input name="price" required class="form-control" type="number" placeholder="Giá bán" id="price">
                        </div>
                        <div class="form-group">
                            <label for="desc">Mô tả</label>
                            <textarea id="desc" name="desc" rows="4" class="form-control" placeholder="Mô tả"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="custom-file">
                                <input name="image" type="file" class="custom-file-input" id="customFile" accept="image/gif, image/jpeg, image/png, image/bmp">
                                <label class="custom-file-label" for="customFile"></label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="id_product" value='' id="id_product">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        const productName = document.querySelector('.product-name');
        const inputName = document.querySelector('.input-name')

        const name = document.querySelector('#name')
        const price = document.querySelector('#price')
        const desc = document.querySelector('#desc')
        const image = document.querySelector('#customFile')
        const id = document.querySelector('#id_product')

        function handleDeleteProduct(name){
            productName.innerHTML= name;
            inputName.value = name;
        }

        function handleEditModel(inputName,inputPrice,inputDesc,inputImage, inputID) {
            name.defaultValue = inputName;
            price.defaultValue = inputPrice;
            desc.defaultValue = inputDesc;
            image.defaultValue = inputImage;
            id.defaultValue = inputID;
        }
    </script>
</body>
</html>
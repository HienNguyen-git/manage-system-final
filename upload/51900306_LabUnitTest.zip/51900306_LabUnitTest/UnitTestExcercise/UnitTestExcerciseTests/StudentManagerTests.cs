﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest.Tests
{
    [TestClass()]
    public class StudentManagerTests
    {
        public StudentManager sm;
        public Student sv1, sv2, sv3;
        [TestInitialize]
        public void Setup()
        {
            sm = new StudentManager();
            sv1 = new Student("51900123", "Bun", 20, 7);
            sv2 = new Student("51900456", "Tran", 22, 7);
            sv3 = new Student("51900555", "Bao", 25, 5);
        }

        [TestMethod()]
        public void addStudentTest()
        {
            //StudentManager sm = new StudentManager();
            Student s = new Student("51900306", "Nguyen Dang", 18, 7);
            bool kq = sm.addStudent(s);
            Assert.AreEqual(true, kq);
        }

        [TestMethod()]
        public void checkNameStudent()
        {
            //StudentManager sm = new StudentManager();
            Student s1 = new Student("51900301", "Nguyen", 21, 8);
            sm.addStudent(s1);
            Assert.AreEqual("Nguyen", sm.list[0].Name);
        }

        [TestMethod()]
        public void addDuplicateStudentTest()
        {
            //StudentManager sm = new StudentManager();
            Student s = new Student("51900306", "Nguyen Dang", 18, 7);
            Student s1 = new Student("51900306", "Nguyen Cao Hai", 18, 7);
            bool kq = sm.addStudent(s);
            kq = sm.addStudent(s1);
            Assert.AreEqual(false, kq);
        }

        [TestMethod()]
        [ExpectedException(typeof(NullReferenceException))]
        public void addNullStudentTest()
        {
            sm.addStudent(null);
        }

        [TestMethod()]
        public void addCountStudentTest()
        {
            //StudentManager sm = new StudentManager();
            Student s = new Student("51900306", "Nguyen Dang", 18, 7);
            Student s1 = new Student("51900330", "Nguyen Cao Hai Dang", 22, 9);
            sm.addStudent(s);
            sm.addStudent(s1);
            Assert.AreEqual(2, sm.list.Count);
        }

        [TestMethod()]
        public void getAverageScoreNoStudentTest()
        {
            try
            {
                double diem = sm.getAverageScore();

            }catch (Exception ex)
            {
                Assert.AreEqual("Student list is empty", ex.Message);
            }

        }

        [TestMethod()]
        public void getAverageScoreTest()
        {
            sm.addStudent(sv1);
            sm.addStudent(sv2);
            double kq = sm.getAverageScore();
            Assert.AreEqual(7, kq);
        }

        [TestMethod()]
        public void getStudentAtTest()
        {
            sm.addStudent(sv1);
            sm.addStudent(sv2);
            Student result = sm.getStudentAt(0);
            Assert.AreEqual(result, sv1);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void getStudentAtOutTest()
        {
            //try
            //{
            sm.addStudent(sv1);
            sm.addStudent(sv2);
            Student result = sm.getStudentAt(10);
            //}
            //catch (ArgumentOutOfRangeException ex)
            //{
            //    Assert.AreEqual("Index {i} is not available in this array" + result, ex.Message);
            //}
        }


        [TestMethod()]
        public void findStudentByAgeTest()
        {
            sm.addStudent(sv1);
            sm.addStudent(sv2);
            Student result = sm.findStudentByAge(20);
            Assert.AreEqual(result, sv1);
        }

        [TestMethod()]
        public void findStudentByAgeNullTest()
        {
            sm.addStudent(sv1);
            sm.addStudent(sv2);
            Student result = sm.findStudentByAge(200);
            Assert.AreEqual(result, null);
        }

        [TestMethod()]
        public void findStudentWithMinScoreNullTest()
        {
            
            Student result = sm.findStudentWithMinScore();
            Assert.AreEqual(null, result);
        }

        [TestMethod()]
        public void findStudentWithMinScoreTest()
        {
            sm.addStudent(sv1);
            sm.addStudent(sv2);
            sm.addStudent(sv3);
            Student result = sm.findStudentWithMinScore();
            Assert.AreEqual(sv3, result);
        }

        
    }
}
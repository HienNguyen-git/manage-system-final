<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Trang chủ - Danh sách sản phẩm</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

    <style>
        body{
            padding-top: 50px;
        }
        table{
            width: 80%;
            text-align: center;
        }
        td{
            padding: 10px;
        }
        tr.item{
            border-top: 1px solid #5e5e5e;
            border-bottom: 1px solid #5e5e5e;
        }

        tr.item:hover{
            background-color: #d9edf7;
        }

        tr.item td{
            min-width: 150px;
        }

        tr.header{
            font-weight: bold;
        }

        a{
            text-decoration: none;
        }
        a:hover{
            color: deeppink;
            font-weight: bold;
        }

        td img {
            max-height: 100px;
        }
    </style>


    <script>
        $(document).ready(function () {
            $(".delete").click(function () {

                $('#myModal').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            });
        });
    </script>


    <table cellpadding="10" cellspacing="10" border="0" style="border-collapse: collapse; margin: auto">

        <thead>
        <tr class="control" style="text-align: left; font-weight: bold; font-size: 20px">
            <td colspan="4">
                <a href="add_product.php" data-toggle="modal" data-target="#add-product">Thêm sản phẩm</a>
            </td>
        </tr>
            <tr class="header">
                <td>ID</td>
                <td>Name</td>
                <td>Price</td>
                <td>Description</td>
                <td>Action</td>
            </tr>
        </thead>
        <tbody class="product-list-body">
        </tbody>
        <tfoot>
            <tr class="control" style="text-align: right; font-weight: bold; font-size: 17px">
                <td colspan="5">
                    <p>Số lượng sản phẩm: <span class="number-of-product"></span></p>
                </td>
            </tr>
        </tfoot>
    </table>

    <!-- Add Modal -->
    <div id="add-product" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <hp class="modal-title">Thêm sản phẩm</hp>
                    <button type="button" class="close" data-dismiss="modal" >&times;</button>
                </div>
                <form id="add-form" method="post" novalidate enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Tên sản phẩm</label>
                            <input name="name" required class="form-control" type="text" placeholder="Tên sản phẩm" id="nameAdd">
                        </div>
                        <div class="form-group">
                            <label for="price">Giá bán</label>
                            <input name="price" required class="form-control" type="number" placeholder="Giá bán" id="priceAdd">
                        </div>
                        <div class="form-group">
                            <label for="desc">Mô tả</label>
                            <textarea id="descAdd" name="desc" rows="4" class="form-control" placeholder="Mô tả"><?= $desc ?></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary px-5 mr-2">Thêm</button>
                        </div>
                    </div>
                </form>
            </div>  
        </div>
    </div>


    <!-- Delete Confirm Modal -->
    <div id="delete-product" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <hp class="modal-title">Xóa sản phẩm</hp>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action=""></form>
                <div class="modal-body">
                    <p>Bạn có chắc rằng muốn xóa <strong class="product-delete-name">iPhone XS MAX</strong> ?</p>
                </div>
                <div class="modal-footer">
                    <input type="hidden">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger" onclick="handBtnDeleteClick()" class="btn-delete-modal" data-dismiss="modal">Xóa</button>
                    
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Confirm Modal -->
    <div id="edit-product-detail" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <hp class="modal-title">Chỉnh sửa thông tin sản phẩm</hp>
                    <button type="button" class="close" data-dismiss="modal" >&times;</button>
                </div>
                <form method="post" id="update-form" novalidate enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Tên sản phẩm</label>
                            <input name="name" required class="form-control" type="text" placeholder="Tên sản phẩm" id="nameUpdate">
                        </div>
                        <div class="form-group">
                            <label for="price">Giá bán</label>
                            <input name="price" required class="form-control" type="number" placeholder="Giá bán" id="priceUpdate">
                        </div>
                        <div class="form-group">
                            <label for="desc">Mô tả</label>
                            <textarea id="descUpdate" name="desc" rows="4" class="form-control" placeholder="Mô tả"></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary px-5 mr-2">Thêm</button>
                        </div>
                    </div>
                </form>
            </div>  
        </div>
    </div>

    <script>
        const productListBody = document.querySelector('.product-list-body');
        const numberOfProduct = document.querySelector('.number-of-product');
        const productDeleteName = document.querySelector('.product-delete-name');

        // Get product data
        (async()=>{
            const res = await fetch('http://localhost/Lab09/get_products.php');
            const dataset = await res.json();

            const handleDataset = dataset.slice();

            const productList =  handleDataset.map(data=>`
                <tr class="item" data-id='${data.id}'>
                    <td>${data.id}</td>
                    <td>${data.name}</td>
                    <td>${data.price} VND</td>
                    <td>${data.description}</td>
                    <td class='action'>
                        <a class="edit-button"
                        onclick="handleTransferToUpdate('${data.id}','${data.name}','${data.price}','${data.description}')" data-toggle="modal" data-target="#edit-product-detail"><i class="fa fa-edit action"></i></a> | <a class="delete-button" href="#" class="delete" 
                        onclick="handleTransferToDelete('${data.name}','${data.id}')" data-toggle="modal" data-target="#delete-product"><i class="fa fa-trash "></i></a>
                    </td>
                </tr>    
            `).join('')

            productListBody.insertAdjacentHTML('afterbegin',productList)
            numberOfProduct.innerHTML = dataset.length
        })();

        // Handle remove product
        async function handleRemove(id){
            console.log(JSON.stringify({id}))
            const request = await fetch('delete_product.php',{
                method: 'delete',
                body: JSON.stringify({id}),
                headers: {
                    "Content-Type": "application/json"
                },
            })
            const res = await request.json();
            console.log(res)
            reloadPage(res)
        }

        // Handle update product 
        async function handleUpdate(id,name,price,desc){
            const request = await fetch(`update_product.php`,{
                method: 'PUT',
                body: JSON.stringify({id,name,price,desc})
            })
            const res = await request.json();
            console.log(res)
            reloadPage(res)
        }
        let currentID;

        // Handle model delete product
        function handleTransferToDelete(name, id){
            productDeleteName.innerHTML = name;
            currentID = id;
        }
        function handBtnDeleteClick(){
            handleRemove(currentID)
        }
        // Handle model update product

        function handleTransferToUpdate(id,name,price,desc){
            console.log(id,name,price,desc)
            currentID = id
            document.querySelector('#nameUpdate').value = name;
            document.querySelector('#priceUpdate').value = price
            document.querySelector('#descUpdate').innerHTML = desc
        }

    </script>
    
    <script>
        const addForm = document.querySelector('#add-form')
        addForm.addEventListener('submit', async (e)=>{
            e.preventDefault();
            const name = document.querySelector('#nameAdd').value
            const price = document.querySelector('#priceAdd').value
            const desc = document.querySelector('#descAdd').value

            const sendRequest = await fetch('add_product.php',{
                method: 'POST',
                body: JSON.stringify({name,price,desc})
            })

            const res = await sendRequest.json();
            console.log(res)
            reloadPage(res)
        })

        document.querySelector('#update-form').addEventListener('submit',async (e)=>{
            e.preventDefault();
            const name = document.querySelector('#nameUpdate').value
            const price = document.querySelector('#priceUpdate').value
            const desc = document.querySelector('#descUpdate').value

            const sendRequest = await fetch('update_product.php',{
                method: 'POST',
                body: JSON.stringify({id:currentID,name,price,desc})
            })

            const res = await sendRequest.json();
            console.log(res)
            reloadPage(res)
        })
    </script>


    <script>
        function reloadPage(res){
            if(res.code===0){
                location.reload();
            }
        }
    </script>
</body>
</html>
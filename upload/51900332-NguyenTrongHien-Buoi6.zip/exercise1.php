<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body{
            display: flex;
            justify-self: center;
            align-items: center;
            flex-direction: column;
        }
        thead {
            background-color: #cccccc;
            text-transform: uppercase;
            text-align: center;
        }
        body th{
            padding: 10px;
        }
        body td{
            padding: 10px;
        }
    </style>
</head>
<body>
    <table class="mt-2"  border="1">
        <thead><th colspan="10">Bảng cửu chương</th></thead>
        <tbody>
        <?php for ($i = 1; $i < 10; $i++) {
          echo "<tr>";
          for ($j = 1; $j < 10; $j++) {
            echo "<td> $j x $i = " . $i * $j . "</td>";
          }
          echo "</tr>";
        } ?>
        </tbody>
    </table>
</body>
</html>


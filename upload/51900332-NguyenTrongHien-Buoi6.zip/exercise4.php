<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
    </style>
</head>
<body>
<?php
    $name = isset($_POST['name']) ? $_POST['name']: '';
    $email = isset($_POST['email']) ? $_POST['email']: '';
    $gender = isset($_POST['gender']) ? $_POST['gender']: '';
    $browsers = isset($_POST['browsers']) ? $_POST['browsers']: '';
    $cars = isset($_POST['cars']) ? $_POST['cars']: '';
    
    if (empty($name)||empty($email)||empty($gender)||empty($browsers)||empty($cars)){
        die("Please input valid data");
    }
?>


    <div class="container">
        <div class="row">
            <div class="col-md-8 col-lg-5 my-5 mx-2 mx-sm-auto border rounded px-3 py-3">
                <h5 class="text-center mb-3">User Information</h5>
                <form action="">

                    <div class="form-group">
                        <label for="name">Your name</label>
                        <p class='text-success font-weight-bold ml-3'><?= $name?></p>
                    </div>
                    <div class="form-group">
                        <label for="email">Your email</label>
                        <p class='text-success font-weight-bold ml-3'><?= $email?></p>
                    </div>
                    <div class="form-group">
                        <legend class="col-form-label">Gender</legend>
                        <p class='text-success font-weight-bold ml-3'><?= $gender?></p>
                    </div>
                    <div class="form-group">
                        <legend class="col-form-label">Favorite web browsers</legend>
                        <?php
                            echo "<ul class='list-group ml-3'>";
                            foreach ($browsers as $value){
                                echo "<li class='text-success font-weight-bold'>$value</li><br/>";
                            }
                            echo "</ul>";

                            ?>
                    </div>
                    <div class="form-group">
                        <legend class="col-form-label">Prefered Operating System</legend>
                        <p class='text-success font-weight-bold ml-3'><?= $cars?></p>
                        
                    </div>
                    <button class="btn btn-success px-5 mr-2">Save</button>
                    <a href="./exercise4.html" class="btn btn-outline-success px-5">Back</a>
                    
                </form>
                </div>
            </div>
    </div>
</body>
</html>


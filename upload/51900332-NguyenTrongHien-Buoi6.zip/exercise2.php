<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <title>PHP Exercises</title>
</head>
<body>
    <?php
    $num1 = 0;
    $num2 = 0;
    $operation = '';
    $display = "";
    $operation = "";
    $errorMsg = "";

    if (isset($_GET["num1"])) {
        $num1 = $_GET["num1"];
    }
    if (isset($_GET["num2"])) {
        $num2 = $_GET["num2"];
    }
    if (isset($_GET["operation"])) {
        $operation = $_GET["operation"];
    }
    
    if ($num1 && $num2 && $operation) {
        switch ($operation) {
            case "+":
                $result = $num1 + $num2;
                $display = "$num1 + $num2 = $result";
                break;
            case "-":
                $result = $num1 - $num2;
                $display = "$num1 - $num2 = $result";
                break;
            case "*":
                $result = $num1 * $num2;
                $display = "$num1 * $num2 = $result";
                break;
            default:
                $result = $num1 / $num2;
                $display = "$num1 / $num2 = $result";
                break;
        }
    } else {
        $errorMsg = "Please input invalid value";
    }
    ?>

    <div class="container">

        <div class="row">
            <div class="col-md-6 my-5 mx-auto border rounded px-3 py-3">
                <h4 class="text-center">Tính toán cơ bản</h4>
                <form method="GET">
                    <div class="form-group">
                        <label for="num1">Số hạng 1</label>
                        <input type="text" class="form-control" id="num1" name="num1">
                    </div>
                    <div class="form-group">
                        <label for="num2">Số hạng 2</label>
                        <input type="text" class="form-control" id="num2" name="num2">
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-radio custom-control-inline">
                            <input name="operation" value="+" id="add" type="radio" class="custom-control-input">
                            <label for="add" type="radio" class="custom-control-label">Cộng</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input name="operation" value="-" id="subtract" type="radio" class="custom-control-input">
                            <label for="subtract" type="radio" class="custom-control-label">Trừ</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input name="operation" value="*" id="multiply" type="radio" class="custom-control-input">
                            <label for="multiply" type="radio" class="custom-control-label">Nhân</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input name="operation" value="/" id="divide" type="radio" class="custom-control-input">
                            <label for="divide" type="radio" class="custom-control-label">Chia</label>
                        </div>
                        <?php if (!($num1 && $num2 && $operation)) {
                            echo "
                                <div class='row'>
                                    <div class='col-md-6 mx-auto px-3 py-3 text-center'>
                                        <div class='alert alert-danger'>
                                            $errorMsg
                                        </div>
                                    </div>
                                </div>
                                
                                ";
                        } ?>
                    </div>
                    <button class="btn btn-success">Xem kết quả</button>
                </form>
            </div>
        </div>

        <?php if ($display) {
            echo "
                <div class='row'>
                    <div class='col-md-6 mx-auto px-3 py-3 text-center'>
                        <div class='alert alert-success'>
                            $display
                        </div>
                    </div>
                </div>
                ";
        } ?>
        
    </div>
</body>
</html>